Zum öffnen der Seite die Datei index.html in einem Browser öffnen.

Empfohlen wird hierbei Chrome oder Firefox.